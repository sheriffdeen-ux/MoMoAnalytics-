# MoMoAnalytics-
MoMo Analytics is an AI-powered fraud detection and financial analytics SaaS platform for Ghana's Mobile Money ecosystem. The system provides real-time transaction monitoring, fraud detection, and spending insights through a WhatsApp-first interface.
